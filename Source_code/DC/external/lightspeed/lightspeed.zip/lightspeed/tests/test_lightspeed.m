disp('Starting tests...')
test_digamma
test_gammaln
test_trigamma
test_int_hist
%test_inv_posdef
test_java
test_logmulexp
test_logsumexp
test_mutable
%test_ndsum
%test_normcdf
test_normpdf
test_randgamma
test_randbeta
test_randbinom
test_randwishart
test_repmat
test_row_sum
test_sameobject
test_scale
test_solve_tri
test_sorted
test_sparse
test_sqdist
test_wishpdf
disp('All tests completed')
